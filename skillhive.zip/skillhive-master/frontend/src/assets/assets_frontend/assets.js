import learntogether from './learntogether.png'
import read from './read.mp4'
import bulb from './bulb.jpg'


export const assets = {
    learntogether,
    read,
    bulb
}

